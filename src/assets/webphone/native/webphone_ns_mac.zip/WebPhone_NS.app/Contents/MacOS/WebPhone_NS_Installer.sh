#!/bin/bash

# WebPhone NS engine install script for MacOS

# Copyright 2021 MizuTech. All rights reserved.
# MizuTech PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.

NSINSTALLERDIR=$(cd `dirname $0` && pwd)

echo "Installing WebPhone NS engine ... "
sudo echo "" || { echo "Please run again as root!";  sudo osascript -e 'display notification "" with title "No install rights. Run again as admin!" subtitle "You don not have enough rights to install. Please run this app again as admin or root user."'; exit 11 ; } ;
sudo osascript -e 'display notification "" with title "WebPhone NS Installing..." subtitle "NS engine install in progress. Please wait..."'

sudo launchctl unload WebPhone_NS
sudo launchctl unload /Applications/WebPhone_NS/WebPhone_NS
sudo launchctl remove WebPhone_NS
sudo launchctl remove /Applications/WebPhone_NS/WebPhone_NS
sudo pkill -x WebPhone_NS
sudo pkill -x WebPhone_Service
sudo pkill -x WebPhone_NS
sudo /Applications/WebPhone_NS/WebPhone_NS /uninstall
sudo pkill -x WebPhone_NS
sudo pkill -x WebPhone_NS
sudo rm -rf /Applications/WebPhone_NS/mwphonedata
sudo rm -f /Applications/WebPhone_NS/WebPhone_NS.stderr.log

sudo mkdir -p /Applications/WebPhone_NS
sudo chmod a+rwx /Applications/WebPhone_NS
sudo cp -f "$NSINSTALLERDIR/WebPhone_Service" "/Applications/WebPhone_NS/WebPhone_NS"
sudo cp -f "$NSINSTALLERDIR/ExInfo.plist" "/Applications/WebPhone_NS/Info.plist"
sudo cp -f "$NSINSTALLERDIR/ring.wav" "/Applications/WebPhone_NS/ring.wav"
sudo cp -f "$NSINSTALLERDIR/mediaenchx64.dylib" "/Applications/WebPhone_NS/mediaenchx64.dylib"
sudo cp -f "$NSINSTALLERDIR/frdm.dat" "/Applications/WebPhone_NS/readme.txt"

LOCALJAVAPATH=/Applications/WebPhone_NS/jre/bin/java

sudo cp -rf "$NSINSTALLERDIR/jre/" "/Applications/WebPhone_NS/jre/"




sudo chmod a+x $LOCALJAVAPATH
sudo chmod a+x /Applications/WebPhone_NS/WebPhone_NS
sudo chmod +x $LOCALJAVAPATH
sudo chmod +x /Applications/WebPhone_NS/WebPhone_NS

sudo /Applications/WebPhone_NS/WebPhone_NS /install auto

RESULT=$?
if [ $RESULT -eq 0 ]; then
	echo ""
else	
	RESULT2=$(sudo /Applications/WebPhone_NS/WebPhone_NS /install auto)
	if [[ "$RESULT2" == *"service already exist"* ]]; then
		RESULT=0
	fi
fi

if [ $RESULT -eq 0 ]; then
	sudo launchctl start WebPhone_NS
	RESULT=$?
	if [ $RESULT -eq 0 ]; then
		echo "WebPhone NS engine installed successfully."
		sudo osascript -e 'display notification "" with title "WebPhone NS engine is ready" subtitle "Now you can begin using VoIP from your browser"'
		cd $NSINSTALLERDIR
		cd ..
        cd ..
		cd ..
		sudo rm -rf $NSINSTALLERDIR		
		sudo rm -f $NSINSTALLERDIR.zip		
		sudo rm -rf WebPhoneNS
		sudo rm -rf WebPhoneNS.app		
		sudo rm -f WebPhoneNS.zip
		sudo rm -f webphone_ns_mac.zip
		sudo rmdir $NSINSTALLERDIR
		sudo rmdir WebPhoneNS
		sudo rmdir WebPhoneNS.app	
        cd /Applications/WebPhone_NS	
		sudo chmod a+rwx /Applications/WebPhone_NS
		echo "Install finished successfully. You can ignore any errors above."	
		exit 0
	else
		echo "Failed to install the WebPhone NS engine."
		sudo osascript -e 'display notification "" with title "Failed to install the WebPhone NS engine" subtitle "Please install the service manually or select another VoIP engine"'
		exit 12
	fi
else
	echo "Failed to start the WebPhone NS engine"
	sudo osascript -e 'display notification "" with title "Failed to start the WebPhone NS engine" subtitle "Please start the service manually or select another VoIP engine"'
	exit 14
fi
exit 15
